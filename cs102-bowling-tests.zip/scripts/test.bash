#!bash

## Colors

hex_to_ansi() {
    HEX_COLOR=$1
    R=0x${HEX_COLOR:1:2}
    G=0x${HEX_COLOR:3:2}
    B=0x${HEX_COLOR:5:2}
    printf "\e[38;2;%d;%d;%dm" $R $G $B
}

RED=$(hex_to_ansi "#e11d48")    # rose 600
GREEN=$(hex_to_ansi "#10b981")  # emerald 500
YELLOW=$(hex_to_ansi "#fde047") # yellow 300
BLUE=$(hex_to_ansi "#3b82f6")   # blue 500
PURPLE=$(hex_to_ansi "#c084fc") # purple 400
ORANGE=$(hex_to_ansi "#ff8200") # UT orange

BOLD='\e[1m'
ITALIC='\e[3m'
RESET_STYLE='\e[0m'

print_styled() {
    STYLE=$1
    MESSAGE="${@:2}"
    printf "$STYLE$MESSAGE$RESET_STYLE\n"

}

print_bold() {
    MESSAGE="$@"
    print_styled "$BOLD" "$MESSAGE"
}

print_success() {
    MESSAGE="$@"
    print_styled "$BOLD$GREEN" "$MESSAGE"
}

print_warning() {
    MESSAGE="$@"
    print_styled "$BOLD$YELLOW" "$MESSAGE"
}

print_error() {
    MESSAGE="$@"
    print_styled "$BOLD$RED" "$MESSAGE"
}

print_blue() {
    MESSAGE="$@"
    print_styled "$BOLD$BLUE" "$MESSAGE"
}

print_purple() {
    MESSAGE="$@"
    print_styled "$BOLD$PURPLE" "$MESSAGE"
}

## Colors

# Check for updates

if
    curl --silent https://raw.githubusercontent.com/seeker-3/curl/main/cs102-bowling-tests.zip -o check.zip &&
        ! cmp --silent check.zip cs102-bowling-tests.zip
then
    mv check.zip cs102-bowling-tests.zip
    unzip -o cs102-bowling-tests.zip
    print_success "Tests were updated, please re-run the script"
    exit
else
    rm -f check.zip
fi

EXIT_ON_FAIL=true

SRC_FILE=$1
BIN_FILE=bowling.bin

TEST_INPUT_DIR=tests/input
TEST_OUTPUT_DIR=tests/output

DIFF_ARGS=$2

# Usage
if [[ -z $SRC_FILE ]]; then
    print_error "Error: no source file specified"
    echo -e "Usage: bash $0 ${BOLD}source-file${RESET_STYLE} diff-flags"
    echo
    echo "Example: bash $0 lab.cpp -yiw"
    exit 1
fi

if ! [[ -f $SRC_FILE ]]; then
    print_error "Error: file '$SRC_FILE' not found."
    exit 1
fi

if ! [[ -d $TEST_INPUT_DIR ]]; then
    print_error "Error: input directory '$TEST_INPUT_DIR' not found."
    exit 1
fi

if ! [[ -d $TEST_OUTPUT_DIR ]]; then
    print_error "Error: output directory '$TEST_OUTPUT_DIR' not found."

    exit 1
fi

# Build
if ! g++ -std=c++11 -Wall -o $BIN_FILE $SRC_FILE; then
    echo
    print_error Build failed.
    exit 1
fi

if ! $EXIT_ON_FAIL; then
    echo
    print_bold Correct output on bottom/right
    echo
    print_bold ----------BEGIN----------
    echo
fi

# Test
for TEST_NAME in $(ls $TEST_INPUT_DIR); do
    INPUT_TEST="$TEST_INPUT_DIR/$TEST_NAME"
    OUTPUT_TEST="$TEST_OUTPUT_DIR/$TEST_NAME"

    if ! diff -y <(./$BIN_FILE <$INPUT_TEST | sed 's/: /: \n/g') $OUTPUT_TEST &>/dev/null; then
        print_error "$TEST_NAME: FAILED"
        echo
        print_blue "YOURS                                                                  EXPECTED "
        echo
        diff --color -y <(./$BIN_FILE <$INPUT_TEST | sed 's/: /: \n/g') $OUTPUT_TEST
        echo
        echo
        if $EXIT_ON_FAIL; then
            printf "Run the test by itself with: ${PURPLE}./$BIN_FILE <$INPUT_TEST | sed 's/: /: %s/g'${RESET_STYLE}\n" '\n'
            printf "View the input with:  ${PURPLE}cat $INPUT_TEST${RESET_STYLE}\n"
            printf "View the output with: ${PURPLE}cat $OUTPUT_TEST${RESET_STYLE}\n"
            exit
        fi
    else
        print_success "$TEST_NAME: PASSED"
    fi
done

if ! $EXIT_ON_FAIL; then
    echo
    print_bold ----------END------------
    echo
    echo Enter additional flags after the first argument to modify the diff output e.g. -y -yw -yiw
    echo bash $0 $SRC_FILE -yiw
    echo Run the file by itself with ./$BIN_FILE
    echo
fi
